import java.awt.*;

public class CustomColors{
    public static final Color GREEN = new Color(0,128,0);
    public static final Color LIGHTGREEN = new Color(0,128,0,80);
    public static final Color RED = new Color(255,0,0);
    public static final Color LIGHTRED = new Color(255,0,0,80);
    public static final Color PURPLE = new Color(128,0,128);
    public static final Color LIGHTPURPLE = new Color(128,0,128,80);
}
