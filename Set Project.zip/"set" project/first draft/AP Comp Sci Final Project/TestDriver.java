public class TestDriver{
    public static void main(String[] args){
        Game myGame = new Game();
        myGame.drawCards();
        System.out.println(myGame.readCards());
    }
}
