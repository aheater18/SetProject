public enum SHADING{
    DARK, LIGHT, EMPTY
}