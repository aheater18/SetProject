public enum SHAPE{
    OVAL, DIAMOND, SQUIGGLE
}